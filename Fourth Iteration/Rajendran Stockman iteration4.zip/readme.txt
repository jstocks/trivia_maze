4th Iteration

- GUI was time-consuming; Varik helped me strategicaly "rethink" my implementation, which took some extensive rework.

- Database creation was straightforward (thanks Sriba!)